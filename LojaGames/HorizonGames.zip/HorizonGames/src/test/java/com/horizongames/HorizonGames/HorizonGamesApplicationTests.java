package com.horizongames.HorizonGames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HorizonGamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
